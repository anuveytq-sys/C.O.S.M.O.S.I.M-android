# COSMOSIM — Android Studio project

This is an Android Studio project that wraps your published COSMOSIM website in a fullscreen, landscape Android app. It loads the existing web version rather than recreating or deleting its simulation features, so the site remains the source of the graphics and controls.

- Original repository: https://github.com/anuveytq-sys/COSMOSIM-
- Website loaded by the app: https://anuveytq-sys.github.io/COSMOSIM-/
- Orientation: landscape
- Display: immersive fullscreen
- Internet: required (the site and its JavaScript/3D libraries are served online)

## Build an APK

1. Extract the ZIP to a normal folder on your computer.
2. Open Android Studio and choose **Open**. Select the extracted `COSMOSIM-Android-Studio` folder (the one containing `settings.gradle.kts`).
3. Let Gradle sync. If prompted, install Android SDK Platform 35 and use JDK 17.
4. When sync finishes, select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio will show a notification with **Locate** to find `app-debug.apk`.

## Important notes

- This is the Android Studio **source project ZIP**, not a precompiled APK.
- It uses your live published website so new web updates can appear in the app without rebuilding, but it will not work fully offline.
- The web page may still have device-specific differences depending on Android WebView/GPU performance. Test on your target phone before sharing the APK.
- If the GitHub Pages site is not published or the URL changes, update `COSMOSIM_URL` in `app/src/main/java/com/cosmosim/app/MainActivity.java`.
